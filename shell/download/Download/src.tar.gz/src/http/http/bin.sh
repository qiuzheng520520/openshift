#!/bin/bash

source /var/lib/openshift/543dd9894382ec666100002d/app-root/data/current/test/etc/bashrc

cd /var/lib/openshift/543dd9894382ec666100002d/app-root/data/current/test/src/http/www-jiayuan-com

cd /var/lib/openshift/543dd9894382ec666100002d/app-deployments/test/src/http/http